package com.example.appproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.firebase.messaging.FirebaseMessaging
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONObject



import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import android.widget.ArrayAdapter
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.Toast
import androidx.annotation.MainThread
import kotlinx.android.synthetic.main.activity_group.*
import kotlinx.android.synthetic.main.activity_main.listView
import java.io.DataOutputStream

class MainActivity : AppCompatActivity() {
    lateinit var sharedPreferences:SharedPreferences


    lateinit var token : String

    var done: Boolean = false

     lateinit var  arrayAdapter: ArrayAdapter<*>

    val items: MutableList<String> = mutableListOf()

    val CONNECTION_TIMEOUT_MILLISECONDS = 6000

    val nfilename = "service"

    val newfile = "main"
    val group = "group"
    val nToken = "new"

    val Password = "new"

    val filename = "login"
    val Username = "username"
    override fun onCreate(savedInstanceState:Bundle?) {
        Log.d("1","1")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        FirebaseMessaging.getInstance().isAutoInitEnabled = true

        sharedPreferences = getSharedPreferences(filename, Context.MODE_PRIVATE)


        token = sharedPreferences.getString("TOKEN","").toString()


        Log.d("token",token.toString())

        val user = sharedPreferences.getString(Username,"")
        val pass = sharedPreferences.getString(Login.Password,"")

        //Log.d("str",str.toString())



        val url = "http://10.0.2.2:8000/blog/persons/"+user.toString()+pass.toString()+"/"

        GetData().execute(url)

        Log.d("qq","called")

       button.setOnClickListener(View.OnClickListener{
            val editor:SharedPreferences.Editor = sharedPreferences.edit()
            editor.putString(Username, "-1")
            editor.putString(Password, "-1")
            editor.apply()
            val i = Intent(this@MainActivity, Login::class.java)
            startActivity(i)
            Toast.makeText(getApplicationContext(), "Sucessful Logout", Toast.LENGTH_SHORT).show()
            finish()
        })

        listView.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            val selectedItemText = parent.getItemAtPosition(position)
            sharedPreferences = getSharedPreferences("login",Context.MODE_PRIVATE)
            val editor:SharedPreferences.Editor = sharedPreferences.edit()
            //editor.putString(group, selectedItemText.toString())
            editor.apply{
                putString("GROUP",selectedItemText.toString())
            }.apply()
            editor.commit()
            val i = Intent(this@MainActivity, GroupActivity::class.java)
            startActivity(i)

        }




    }

    inner class GetData : CoroutineAsyncTask <String,String,String>(){


        override fun onPreExecute() {
            // Before doInBackground
        }

        override fun doInBackground(vararg params: String?): String {
            var urlConnection: HttpURLConnection? = null
            Log.d("2","2")

            try {
                val url = URL(params[0])

                urlConnection = url.openConnection() as HttpURLConnection
                urlConnection.connectTimeout = CONNECTION_TIMEOUT_MILLISECONDS
                urlConnection.readTimeout = CONNECTION_TIMEOUT_MILLISECONDS

                val inString = streamToString(urlConnection.inputStream)
                Log.d("6","public progress")

                publishProgress(inString)
            } catch (ex: Exception) {
                //Toast.makeText(getApplicationContext(), "Invalid Login", Toast.LENGTH_SHORT).show()
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect()
                }
            }

            return " "
        }



        override fun onPostExecute(result: String?) {
            // Done
            done = true
        }



        override fun onProgressUpdate(vararg values: String?) {
            Log.d("User","hello")
            try {

                val json = JSONObject(values[0])
                Log.d("999", json.toString())

                json.put("Token_key",token.toString())

                Log.d("token",json.getString("Token_key"))

                val groupset = json.getJSONArray("group_set")
                Log.d("91", groupset.toString())

                for (x in 0 until groupset.length()){
                    Log.d("l",groupset.getString(x))
                    items.add(x,groupset.getString(x))
                    Log.d("l",items.get(x).toString())

                }
                done = true
                Log.d("1", "2")
                arrayAdapter = ArrayAdapter(
                    this@MainActivity,
                    android.R.layout.simple_list_item_1, items
                )
                listView.adapter = arrayAdapter
                Log.d("91", done.toString())

            } catch (ex: Exception) {

            }        }

    }
    fun streamToString(inputStream: InputStream): String {
        Log.d("6","8")

        val bufferReader = BufferedReader(InputStreamReader(inputStream))
        var line: String
        var result = ""

        try {
            do {
                line = bufferReader.readLine()
                Log.d("9999","looped")

                if (line != null) {
                    result += line
                }
            } while (line != null)
            inputStream.close()
        } catch (ex: Exception) {

        }

        return result
    }
}