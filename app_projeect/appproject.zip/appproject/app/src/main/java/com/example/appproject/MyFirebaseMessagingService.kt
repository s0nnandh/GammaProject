package com.example.appproject

import android.annotation.SuppressLint
import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import android.app.NotificationManager
import android.media.RingtoneManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import  android.widget.Toast
import android.content.SharedPreferences


class MyFirebaseMessagingService : FirebaseMessagingService() {
    public val TAG = "FirebaseMessagngService"

    internal lateinit  var sharedPreferences:SharedPreferences

    override fun onNewToken(s: String): kotlin.Unit {
        super.onNewToken(s)
        Log.d("NEW_TOKEN", s)
        val str = s
        sharedPreferences = getSharedPreferences("login", Context.MODE_PRIVATE)
        val editor:SharedPreferences.Editor = sharedPreferences.edit()
        editor.putString("TOKEN", str)
        Log.d("token", str)
        editor.apply()
        editor.commit()
        val t = sharedPreferences.getString("TOKEN","")
        Log.d("shared",t.toString())
    }


    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        Log.d(TAG, "Notification from phone: ${remoteMessage.from}")

        if (remoteMessage.notification != null) {
            Log.d(TAG, "Message Notification Body: " + remoteMessage.notification!!.toString());
        }
    }
    companion object {
        val nfilename = "service"
        val nToken = "use"
    }


}