package com.example.appproject
import android.util.Log
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope

abstract class CoroutineAsyncTask<Params, Progress, Result> {
    open fun onPreExecute(){}

    abstract fun doInBackground(vararg params: Params?): Result

    abstract fun onProgressUpdate(vararg values: Progress?)

    open fun onPostExecute(result: Result?){}

    protected fun publishProgress(vararg progress: Progress?) {
        GlobalScope.launch(Dispatchers.Main){

            onProgressUpdate(*progress )
            Log.d("6","publish pro")

        }
    }

    fun execute(vararg params: Params?){
        GlobalScope.launch(Dispatchers.Default){
            Log.d("6","80000")
            val result = doInBackground(*params)

        }
    }

}