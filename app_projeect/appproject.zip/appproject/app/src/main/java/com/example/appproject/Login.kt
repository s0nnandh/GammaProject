package com.example.appproject
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.widget.Button
import android.widget.TextView
import  android.widget.Toast
import android.content.SharedPreferences
import android.util.Log
import android.widget.EditText
import android.view.View
import java.net.HttpURLConnection
import java.net.URL
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONObject
import java.io.*


class Login:AppCompatActivity() {
    internal lateinit var etUsername:EditText
    internal lateinit var etPassword:EditText
    internal lateinit  var btnLogin:Button
    internal lateinit  var sharedPreferences:SharedPreferences

    lateinit var user:String
    lateinit var pass:String

    val CONNECTION_TIMEOUT_MILLISECONDS = 6000

    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        etUsername = findViewById(R.id.etUsername)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        sharedPreferences = getSharedPreferences("login", Context.MODE_PRIVATE)
        //nsharedPreferences = getSharedPreferences(nfilename,Context.MODE_PRIVATE)
        if (sharedPreferences.getString(Username,"")!="-1" && sharedPreferences.getString(Username,"")!="")
        {
            val i = Intent(this@Login, MainActivity::class.java)
            startActivity(i)
            finish()
        }
        btnLogin.setOnClickListener(View.OnClickListener{
            user = etUsername.getText().toString()
            pass = etPassword.getText().toString()
            Log.d("USER//",user)
            val url = "http://10.0.2.2:8000/blog/persons/"+user+pass+"/"
            Log.i("url",url)
            GetData().execute(url)

        })
    }
    companion object {
        val nfilename = "service"
        val filename = "login"
        val Username = "username"
        val Password = "password"
        val Ntoken = "token"
    }
    fun streamToString(inputStream: InputStream): String {
        Log.d("6","8")

        val bufferReader = BufferedReader(InputStreamReader(inputStream))
        var line: String
        var result = ""

        try {
            do {
                line = bufferReader.readLine()
                Log.d("9999","looped")

                if (line != null) {
                    result += line
                }
            } while (line != null)
            inputStream.close()
        } catch (ex: Exception) {
            print(ex)
        }

        return result
    }
    inner class GetData : CoroutineAsyncTask <String,String,String>(){

        lateinit var out : OutputStreamWriter

        lateinit var urlConnection: HttpURLConnection

        lateinit var con: HttpURLConnection

        override fun onPreExecute() {
            // Before doInBackground
        }

        override fun doInBackground(vararg params: String?): String {

            Log.d("2","2")

            try {
                val url = URL(params[0])

                urlConnection = url.openConnection() as HttpURLConnection
                urlConnection.connectTimeout = CONNECTION_TIMEOUT_MILLISECONDS
                urlConnection.readTimeout = CONNECTION_TIMEOUT_MILLISECONDS

                val inString = streamToString(urlConnection.inputStream)
                Log.d("6","public progress")


                publishProgress(inString)
            } catch (ex: Exception) {
                ////Toast.makeText(getApplicationContext(), "Invalid Login", Toast.LENGTH_SHORT).show()
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect()
                }
            }

            return " "
        }



        override fun onPostExecute(result: String?) {
            // Done

        }



        override fun onProgressUpdate(vararg values: String?) {
            Log.d("User","hello")
            try {

                val json = JSONObject(values[0])
                Log.d("999", json.toString())

                val username = json.getString("userid")
                val password = json.getString("password")

                Log.d("User",username.toString())
                Log.d("Password",password.toString())

                if (user == username.toString() && pass == password.toString()) {

                    //sharedPreferences = getSharedPreferences("login",Context.MODE_PRIVATE)
                    val str = sharedPreferences.getString("TOKEN", "")
                    Log.d("token3",str.toString())
                    val obj = JSONObject(json.toString())
                    obj.put("Token_key",str)

                    val nurl = "http://10.0.2.2:8000/blog/persons/"+user+pass+"/"
                    Log.d("furl",nurl)
                    val furl = URL(nurl)

                    val thread = Thread(object:Runnable {
                        public override fun run() {
                            try
                            {
                                val url = URL(nurl)
                                val conn = url.openConnection() as HttpURLConnection
                                conn.setRequestProperty("Content-Type", "application/json;charset=UTF-8")
                                conn.setRequestMethod("PUT")
                                conn.setRequestProperty("Accept", "application/json")
                                conn.setDoOutput(true)
                                conn.setDoInput(true)
                                Log.i("JSON", obj.toString())
                                val os = DataOutputStream(conn.getOutputStream())
                                os.writeBytes(obj.toString())
                                os.flush()
                                os.close()
                                Log.i("STATUS", conn.getResponseCode().toString())
                                Log.i("MSG", conn.getResponseMessage())

                                val reader = BufferedReader(InputStreamReader(conn.getInputStream()))
                                try {
                                    val results = StringBuilder()
                                    while (true) {
                                        val line = reader.readLine()
                                        if (line == null) break
                                        results.append(line)
                                    }
                                    val inputAsString = results.toString()
                                    Log.d("JSON",results.toString())
                                } finally {
                                    reader.close()
                                }

                                conn.disconnect()
                            }
                            catch (e:Exception) {
                                e.printStackTrace()
                            }
                        }
                    })
                    thread.start()

                    obj.put("userid",username)
                    json.put("Token_key",str)
                    Log.d("finnaly done",json.getString("Token_key"))
                    val editor:SharedPreferences.Editor = sharedPreferences.edit()
                    editor.putString(Username, user)
                    editor.putString(Password, pass)
                    editor.apply()
                    editor.commit()
                    Toast.makeText(getApplicationContext(), "Sucessful Login", Toast.LENGTH_SHORT).show()
                    Log.d("USER",sharedPreferences.getString(Username,"").toString())
                    val i = Intent(this@Login, MainActivity::class.java)
                    startActivity(i)
                    finish()
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Invalid Login", Toast.LENGTH_SHORT).show()
                    etUsername.setText("")
                    etUsername.requestFocus()
                    etPassword.setText("")
                }

            } catch (ex: Exception) {
                ex.printStackTrace()
                Toast.makeText(getApplicationContext(), "Error Occured", Toast.LENGTH_SHORT).show()
            }
        }

    }

}