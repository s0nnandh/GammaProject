package com.example.appproject

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_message.*
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class MessageActivity : AppCompatActivity() {

    lateinit var sharedPreferences: SharedPreferences

    lateinit var  arrayAdapter: ArrayAdapter<*>

    val items: MutableList<String> = mutableListOf()

    val CONNECTION_TIMEOUT_MILLISECONDS = 6000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_message)

        sharedPreferences = getSharedPreferences("login", Context.MODE_PRIVATE)
        val str = sharedPreferences.getString("Message","")

        Log.d("str",str.toString())

        val url = "http://10.0.2.2:8000/blog/messages/"+str.toString()+"/"

        GetData().execute(url)
    }

    inner class GetData : CoroutineAsyncTask <String,String,String>(){


        override fun onPreExecute() {
            // Before doInBackground
        }

        override fun doInBackground(vararg params: String?): String {
            var urlConnection: HttpURLConnection? = null
            Log.d("2","2")

            try {
                val url = URL(params[0])

                urlConnection = url.openConnection() as HttpURLConnection
                urlConnection.connectTimeout = CONNECTION_TIMEOUT_MILLISECONDS
                urlConnection.readTimeout = CONNECTION_TIMEOUT_MILLISECONDS

                val inString = streamToString(urlConnection.inputStream)
                Log.d("6","public progress")

                publishProgress(inString)
            } catch (ex: Exception) {

            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect()
                }
            }

            return " "
        }



        override fun onPostExecute(result: String?) {
            // Done
            //done = true
        }



        override fun onProgressUpdate(vararg values: String?) {
            Log.d("User","hello")
            try {

                val json = JSONObject(values[0])
                Log.d("999", json.toString())

                val header = json.getString("header")
                val text = json.getString("text")

                textView1.setText(header)
                textView2.setText(text)
                //json.put("Token_key",token.toString())

                //Log.d("token",json.getString("Token_key"))


                // done = true
                Log.d("1", "2")
                //Log.d("91", done.toString())

            } catch (ex: Exception) {

            }        }

    }
    fun streamToString(inputStream: InputStream): String {
        Log.d("6","8")

        val bufferReader = BufferedReader(InputStreamReader(inputStream))
        var line: String
        var result = ""

        try {
            do {
                line = bufferReader.readLine()
                Log.d("9999","looped")

                if (line != null) {
                    result += line
                }
            } while (line != null)
            inputStream.close()
        } catch (ex: Exception) {

        }

        return result
    }
}