package com.example.appproject

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.AdapterView
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONObject
import java.io.BufferedReader
import java.io.DataOutputStream
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class GroupActivity : AppCompatActivity() {

    lateinit var sharedPreferences: SharedPreferences

    lateinit var  arrayAdapter: ArrayAdapter<*>

    val items: MutableList<String> = mutableListOf()

    val CONNECTION_TIMEOUT_MILLISECONDS = 6000

    val filename = "main"
    val group = "group"
    val Username = "hello"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_group)
        Log.d("hi","groups")

        sharedPreferences = getSharedPreferences("login", Context.MODE_PRIVATE)
        val str = sharedPreferences.getString("GROUP","")

        Log.d("str",str.toString())

        val url = "http://10.0.2.2:8000/blog/groups/"+str.toString()+"/"

        GetData().execute(url)

        listView.onItemClickListener = AdapterView.OnItemClickListener { parent, view, position, id ->
            val selectedItemText = parent.getItemAtPosition(position)
            sharedPreferences = getSharedPreferences("login",Context.MODE_PRIVATE)


            val editor:SharedPreferences.Editor = sharedPreferences.edit()
            //editor.putString(group, selectedItemText.toString())
            editor.apply{
                putString("Message",selectedItemText.toString())
            }.apply()
            editor.commit()
            val nurl = "http://10.0.2.2:8000/blog/mess/";
            //val furl = URL(nurl)
            val nuser = sharedPreferences.getString(Login.Username,"")
            Log.i("nuser",nuser.toString())
            val obj = JSONObject("""{"person":"a","form2":"a"}""")
            obj.put("person",nuser.toString())
            obj.put("form2",selectedItemText)
            val thread = Thread(object:Runnable {
                public override fun run() {
                    try
                    {
                        val furl = URL(nurl)
                        val conn = furl.openConnection() as HttpURLConnection
                        conn.setRequestProperty("Content-Type", "application/json;charset=UTF-8")
                        conn.setRequestMethod("POST")
                        conn.setRequestProperty("Accept", "application/json")
                        conn.setDoOutput(true)
                        conn.setDoInput(true)
                        Log.i("JSON", obj.toString())
                        val os = DataOutputStream(conn.getOutputStream())
                        os.writeBytes(obj.toString())
                        os.flush()
                        os.close()
                        Log.i("STATUS", conn.getResponseCode().toString())
                        Log.i("MSG", conn.getResponseMessage())

                        val reader = BufferedReader(InputStreamReader(conn.getInputStream()))
                        try {
                            val results = StringBuilder()
                            while (true) {
                                val line = reader.readLine()
                                if (line == null) break
                                results.append(line)
                            }
                            val inputAsString = results.toString()
                            Log.d("JSON",results.toString())
                        } finally {
                            reader.close()
                        }

                        conn.disconnect()
                    }
                    catch (e:Exception) {
                        e.printStackTrace()
                    }
                }
            })
            thread.start()

            val i = Intent(this@GroupActivity, MessageActivity::class.java)
            startActivity(i)
        }

    }
    inner class GetData : CoroutineAsyncTask <String,String,String>(){


        override fun onPreExecute() {
            // Before doInBackground
        }

        override fun doInBackground(vararg params: String?): String {
            var urlConnection: HttpURLConnection? = null
            Log.d("2","2")

            try {
                val url = URL(params[0])

                urlConnection = url.openConnection() as HttpURLConnection
                urlConnection.connectTimeout = CONNECTION_TIMEOUT_MILLISECONDS
                urlConnection.readTimeout = CONNECTION_TIMEOUT_MILLISECONDS

                val inString = streamToString(urlConnection.inputStream)
                Log.d("6","public progress")

                publishProgress(inString)
            } catch (ex: Exception) {

            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect()
                }
            }

            return " "
        }



        override fun onPostExecute(result: String?) {
            // Done
            //done = true
        }



        override fun onProgressUpdate(vararg values: String?) {
            Log.d("User","hello")
            try {

                val json = JSONObject(values[0])
                Log.d("999", json.toString())

                //json.put("Token_key",token.toString())

                //Log.d("token",json.getString("Token_key"))

                val groupset = json.getJSONArray("messages")
                Log.d("91", groupset.toString())

                for (x in 0 until groupset.length()){
                    Log.d("l",groupset.getString(x))
                    items.add(x,groupset.getString(x))
                    Log.d("l",items.get(x).toString())

                }
               // done = true
                Log.d("1", "2")
                arrayAdapter = ArrayAdapter(
                    this@GroupActivity,
                    android.R.layout.simple_list_item_1, items
                )
                listView.adapter = arrayAdapter
                //Log.d("91", done.toString())

            } catch (ex: Exception) {

            }        }

    }
    fun streamToString(inputStream: InputStream): String {
        Log.d("6","8")

        val bufferReader = BufferedReader(InputStreamReader(inputStream))
        var line: String
        var result = ""

        try {
            do {
                line = bufferReader.readLine()
                Log.d("9999","looped")

                if (line != null) {
                    result += line
                }
            } while (line != null)
            inputStream.close()
        } catch (ex: Exception) {

        }

        return result
    }
}